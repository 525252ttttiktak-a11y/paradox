package com.paradox.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        val title = TextView(this).apply { text = "Парадокс"; textSize = 32f }
        val key = EditText(this).apply {
            hint = "API-ключ Anthropic"
            setText(prefs.getString("k", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val cmd = EditText(this).apply { hint = "Что сделать? Например: открой Настройки и включи Wi-Fi" }
        val status = TextView(this).apply { text = "Статус: готов"; textSize = 16f }
        val btnSvc = Button(this).apply {
            text = "1. Включить службу"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val btnRun = Button(this).apply {
            text = "2. Выполнить"
            setOnClickListener {
                val s = ParadoxService.instance
                val k = key.text.toString().trim()
                if (s == null) {
                    status.text = "Сначала включи службу «Парадокс» (кнопка 1)"
                } else if (k.isEmpty() || cmd.text.isBlank()) {
                    status.text = "Нужны API-ключ и команда"
                } else {
                    prefs.edit().putString("k", k).apply()
                    moveTaskToBack(true)
                    s.run(cmd.text.toString(), k) { m ->
                        runOnUiThread {
                            status.text = m
                            Toast.makeText(this@MainActivity, m, Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }
        val btnStop = Button(this).apply {
            text = "СТОП"
            setOnClickListener { ParadoxService.stop = true }
        }
        listOf(title, key, cmd, btnSvc, btnRun, btnStop, status).forEach { root.addView(it) }
        setContentView(root)
    }
}
